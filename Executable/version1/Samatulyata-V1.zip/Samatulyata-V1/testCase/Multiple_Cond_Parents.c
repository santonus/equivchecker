#include <stdio.h>

void main () {
    int a;
    scanf ("%d", &a);
    if (a > 10)
        if (a < 20)
            printf ("%d", a);
    
    a += 10;
    printf ("%d", a);
}
