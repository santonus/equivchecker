#include <stdio.h>
void main (){
    int a, i;
    scanf ("%d", &a);
    if (a < 10) {
        while (a < 20) {
            a++;
            for (i = 0; i < 5; i++) {
                a += 2;
            }
        }
    }
    else
        a--;
    
    printf ("%d", a);
}