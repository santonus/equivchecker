#include <stdio.h>

void main ()
{
    /* Simple if-else:
     * It adds an uncessary if-else which doesn't have any effect on 
     *    the program. 
     * Path Constructor: NOT WORKING */
    int a, b, c, d, e, f, g, h, k;
    scanf ("%d", &c);
    a = b = d = 0;
    if (c > 0)
        a = c + 10;
    else
        b = c - 10;
    
    if (d > 0)
        g = d;
    else
        h = d;
        
    d = a + b;
    
    printf ("%d", d);
    
}
