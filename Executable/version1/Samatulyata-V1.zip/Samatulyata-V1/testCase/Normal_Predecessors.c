#include <stdio.h>

void main () {
    int a;
    scanf ("%d", &a);
    if (a > 10)
        a = 0;
    else
        a = 1;
    printf ("%d", a);
}