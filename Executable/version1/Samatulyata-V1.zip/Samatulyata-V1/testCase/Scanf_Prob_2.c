#include <stdio.h>

void main () {
    int a, b, c;
    scanf ("%d", &c);
    if (c > 0) {
        scanf ("%d", &a);
        if (a > 10)
            a = 0;
        else 
            a =  1;
        a = a + 3 + c + b;
        scanf ("%d", &b);
        printf ("%d", a);
        a = a + b;
        b = b + 10;
        printf ("%d", a);
        printf ("%d", b);
    }

    printf ("%d", c);
}