#include <stdio.h>
void main () {
    int a, b, c, i;
    scanf ("%d", &a);
    b = 2;
    if (a == 2)
        a++;
    else
        a--;
    for (i = 0; i < 10 ; i++) {
        b = a + 2;
        c = b + 3;
        b = a + 4;
    }
    printf ("%d", b);
}
 