#include <stdio.h>

void main ()
{
    /* Simple For example: Sum of First n OR 9 natural numbers:  
     * Path Constructor:
     *     WORKING. Extra output places not constructed. */
    int s, x, i, n;
    //scanf ("%d", &n);
    s = x = 0;
    
    for (i = 0; i < 9; i++)
    {
        x += i;
        s = x;
    }
    
   // printf ("%d", s); 

}
