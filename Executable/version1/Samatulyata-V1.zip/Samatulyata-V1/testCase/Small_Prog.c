#include <stdio.h>

void main ()
{
    int a, b, c;
    a = b + c;
}