#include <stdio.h>

void main () {
    int a, b, i;
    scanf ("%d", &a);
    scanf ("%d", &b);
    i = 0;
    while (i < 10) {
        i += 1;
        a = a + b;
        if (b < 5) 
            scanf ("%d", &b);
            // c = c + b;
        else
            b = b - 10;
            // c = c - b;
    }
}