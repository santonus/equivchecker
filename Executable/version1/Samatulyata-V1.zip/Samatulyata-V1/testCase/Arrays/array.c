#include <stdio.h>

void main ()
{
    int arr[10];
    
    int a, b, c;
    
    a = arr[2];
    
    arr [3] = b;
    
    arr[4] = 10;
    
    arr [5] = arr[2] + 10;
    
    arr [6] = arr [7] + arr[3];
    
    b = arr[3] + arr[8];
    
    arr[8] = a + b;
    
    scanf ("%d", &arr[0]);
    
    printf ("%d", arr[9]);
}
